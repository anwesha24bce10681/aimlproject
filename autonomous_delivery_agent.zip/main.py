import heapq
import time
import random

# -----------------------------
# Environment Model
# -----------------------------
class GridEnvironment:
    def __init__(self, grid, dynamic_obstacles=None):
        self.grid = grid
        self.rows = len(grid)
        self.cols = len(grid[0])
        self.dynamic_obstacles = dynamic_obstacles or []

    def in_bounds(self, pos):
        (x, y) = pos
        return 0 <= x < self.rows and 0 <= y < self.cols

    def passable(self, pos, t=0):
        (x, y) = pos
        if self.grid[x][y] == -1:
            return False
        for obs in self.dynamic_obstacles:
            if obs.position_at(t) == pos:
                return False
        return True

    def neighbors(self, pos, t=0):
        (x, y) = pos
        results = [(x+1, y), (x-1, y), (x, y+1), (x, y-1)]
        results = filter(self.in_bounds, results)
        results = filter(lambda p: self.passable(p, t), results)
        return results

    def cost(self, pos):
        (x, y) = pos
        return self.grid[x][y]


class DynamicObstacle:
    def __init__(self, path):
        self.path = path

    def position_at(self, t):
        return self.path[t % len(self.path)]


# -----------------------------
# Search Algorithms
# -----------------------------
def bfs(env, start, goal):
    frontier = [(start, [])]
    explored = set()
    while frontier:
        (pos, path) = frontier.pop(0)
        if pos == goal:
            return path + [pos]
        explored.add(pos)
        for nxt in env.neighbors(pos):
            if nxt not in explored:
                frontier.append((nxt, path + [pos]))
    return None


def uniform_cost_search(env, start, goal):
    frontier = [(0, start, [])]
    explored = {}
    while frontier:
        (cost, pos, path) = heapq.heappop(frontier)
        if pos == goal:
            return path + [pos], cost
        if pos in explored and explored[pos] <= cost:
            continue
        explored[pos] = cost
        for nxt in env.neighbors(pos):
            heapq.heappush(frontier, (cost + env.cost(nxt), nxt, path + [pos]))
    return None, float('inf')


def heuristic(a, b):
    (x1, y1) = a
    (x2, y2) = b
    return abs(x1 - x2) + abs(y1 - y2)


def astar(env, start, goal):
    frontier = [(0, start, [], 0)]
    explored = {}
    while frontier:
        (est, pos, path, cost) = heapq.heappop(frontier)
        if pos == goal:
            return path + [pos], cost
        if pos in explored and explored[pos] <= cost:
            continue
        explored[pos] = cost
        for nxt in env.neighbors(pos):
            g = cost + env.cost(nxt)
            f = g + heuristic(nxt, goal)
            heapq.heappush(frontier, (f, nxt, path + [pos], g))
    return None, float('inf')


def hill_climb_replan(env, start, goal, max_restarts=5):
    def random_path():
        path = [start]
        while path[-1] != goal:
            neighbors = list(env.neighbors(path[-1]))
            if not neighbors:
                break
            nxt = random.choice(neighbors)
            if nxt in path:
                break
            path.append(nxt)
        return path

    best = None
    best_cost = float('inf')
    for _ in range(max_restarts):
        path = random_path()
        cost = sum(env.cost(p) for p in path) if path[-1] == goal else float('inf')
        if cost < best_cost:
            best, best_cost = path, cost
    return best, best_cost


# -----------------------------
# Example Usage
# -----------------------------
def main():
    # 0 = flat terrain, higher numbers = higher cost, -1 = obstacle
    grid = [
        [1, 1, 1, 1, 1],
        [1, -1, -1, -1, 1],
        [1, 1, 1, -1, 1],
        [1, -1, 1, 1, 1],
        [1, 1, 1, 1, 1]
    ]

    dynamic_obstacles = [DynamicObstacle([(2, 2), (2, 3), (2, 2), (2, 1)])]
    env = GridEnvironment(grid, dynamic_obstacles)

    start, goal = (0, 0), (4, 4)

    print("BFS Path:", bfs(env, start, goal))
    path, cost = uniform_cost_search(env, start, goal)
    print("UCS Path:", path, "Cost:", cost)
    path, cost = astar(env, start, goal)
    print("A* Path:", path, "Cost:", cost)
    path, cost = hill_climb_replan(env, start, goal)
    print("Hill-Climb Path:", path, "Cost:", cost)


if __name__ == "__main__":
    main()
